#ifndef DIRECTION_H
#define DIRECTION_H

enum Direction { UP, DOWN, LEFT, RIGHT };

#endif